public class pm {
	public static void main(String[] args){
	pmFrame erep = new pmFrame("인사관리 as프로그램");
}
}
